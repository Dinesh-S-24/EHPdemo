/*********************************************************************************************************************
*
*     Name:                    Web Socket Client
*     Version:                 1.0
*     Description:             This is the javascript file having source code for a simple WebSocket Client. 
*							   This establishes a wensocket communication between client and Server. 
*							   The Web Socket client communicates with the Server and handles the client accordingly.
*
**********************************************************************************************************************/

var webSocketConnection;
//var webSocketServerAddress = "ws://103.86.176.247:9001";
//var webSocketServerAddress = "ws://iotserver.ortusolis.in:7445";
var webSocketServerAddress = "ws://localhost:6777";
//var webSocketServerAddress = "ws://192.168.43.128:65000";
var TempValues = new Array();
var sensor2TempValues = new Array();
var HumValues = new Array();
var sensor2HumValues = new Array();
var xaxisValues = new Array();
var TareValues = new Array();
var xaxisValuesForHum = new Array();
var upperLimitvalues = new Array();
var lowerLimitValues = new Array();
var dayTemp1 = new Array();
var dayHum1 = new Array();
var dayTemp2 = new Array();
var dayHum2 = new Array();
var dayTemp3 = new Array();
var dayHum3 = new Array();
var dayTemp4 = new Array();
var dayHum4 = new Array();
var dayTemp5 = new Array();
var dayHum5 = new Array();
var dayTemp6 = new Array();
var dayHum6 = new Array();
var dayTemp7 = new Array();
var dayHum7 = new Array()

var dayTemp8 = new Array();
var dayHum8 = new Array();
var dayTemp9 = new Array();
var dayHum9 = new Array();
var dayTemp10 = new Array();
var dayHum10 = new Array();
var dayTemp11 = new Array();
var dayHum11 = new Array();
var dayTemp12 = new Array();
var dayHum12 = new Array();
var dayTemp13 = new Array();
var dayHum13 = new Array();
var dayTemp14 = new Array();
var dayHum14 = new Array();

var weekTemp1 = new Array();
var weekTemp2 = new Array();
var weekTemp3 = new Array();
var weekTemp4 = new Array();
var weekTemp5 = new Array();
var weekHum1 = new Array();
var weekHum2 = new Array();
var weekHum3 = new Array();
var weekHum4 = new Array();
var weekHum5 = new Array();


var weekTemp6 = new Array();
var weekTemp7 = new Array();
var weekTemp8 = new Array();
var weekTemp9 = new Array();
var weekTemp10 = new Array();
var weekHum6 = new Array();
var weekHum7 = new Array();
var weekHum8 = new Array();
var weekHum9 = new Array();
var weekHum10 = new Array();



function oConnectToWSServer() {

    webSocketConnection = new WebSocket(webSocketServerAddress);

    webSocketConnection.onopen = function (err) {
        if (webSocketConnection.readyState === WebSocket.OPEN) {
            //alert("Connected ! !");
            initialHandshake();
        } else {
            alert('ERROR UNABLE TO CONNECT TO SERVER');
        }
    };

    webSocketConnection.onmessage = function (message) {
        if (typeof message.data === 'string') {
            console.log("Received: " + message.data);
            var incomingMessage = JSON.parse(message.data);
            oHandleIncomingServerMessage(incomingMessage);
        } else {
            /*FOR FUTURE USE BINARY DATA*/
        }
    }
}

function oHandleIncomingServerMessage(inMessage) {
    var incomingMessage = inMessage;
    if (incomingMessage.resp === null) {
        alert('Data Corrupted');
    }

    switch (incomingMessage.resp) {

        case "DASBOARD_INIT":
            requestSensorLiveData();
            requestSensorData();
            break;

        case '110':
            // document.getElementById("temp1").innerHTML = incomingMessage.data[0].T;
            // document.getElementById("hum1").innerHTML = incomingMessage.data[0].H;
            // document.getElementById("temp2").innerHTML = incomingMessage.data[1].T;
            // document.getElementById("hum2").innerHTML = incomingMessage.data[1].H;
            var NW = incomingMessage.netweight;
            var TW = incomingMessage.tareweight;
            var GW = incomingMessage.grossweight;
            var OL = incomingMessage.overload;
            var SN = incomingMessage.scalenumber;
            document.getElementById("temp").innerHTML = NW;
            document.getElementById("DevId").innerHTML = incomingMessage.deviceId;
            document.getElementById("hum").innerHTML = TW;
            document.getElementById("state").innerHTML = OL;
            document.getElementById("mode").innerHTML = GW;
            document.getElementById("SclNum").innerHTML = SN;
            break;

        case 'GET_SENSOR_DATA':
            TempValues.length = 0;
            HumValues.length = 0;
            TareValues.length = 0;
            xaxisValues.length = 0;
            var count;

            // TempValues = [32, 34, 40, 35, 33];
            // HumValues = [80, 75, 69, 40, 70];
            // TareValues = [2.6, 2.6, 2.6, 2.6, 2.6];

            TempValues = incomingMessage.netweight;
            HumValues = incomingMessage.grossweight;
            TareValues = incomingMessage.tareweight;

            if (TempValues.length > HumValues.length) {
                count = TempValues.length;
            }
            else {
                count = HumValues.length;
            }
            for (var i = 0; i < count; i++) {
                xaxisValues.push(i);
            }
            DataGraph(TempValues, HumValues, TareValues, xaxisValues);
            break;

        default:
            break;
    }
}

/***********************************************************************************************************************
 * @function    : initialHandshake()
 * @description : Function called to make request for updating Connection Id 
 ************************************************************************************************************************/
function initialHandshake() {
    var JSONMessage = {
        action: "DASBOARD_INIT",
        deviceId: 'EHPDASH001',
        clientId: "1A"
    }
    oSendRequestToServer(JSON.stringify(JSONMessage));
    //requestSensorLiveData();
    //requestSensorData();
}

/*********************************************************************************************************
 * @function    : requestSensorLiveData()
 * @description : Function called to make request for sensor's live data
 ************************************************************************************************************/
function requestSensorLiveData() {
    var JSONMessage = {
        action: "110",
        deviceId: 'EHP001',
        dashboardId: "EHPDASH001"
    }
    oSendRequestToServer(JSON.stringify(JSONMessage));
}

/********************************************************************************************
 * @function    : requestSensorData()
 * @description : Function called to make request for sensor's data 
 *************************************************************************************************/
function requestSensorData() {
    var JSONMessage = {
        action: "GET_SENSOR_DATA",
        deviceId: 'EHP001',
        dashboardId: "EHPDASH001"
    }
    oSendRequestToServer(JSON.stringify(JSONMessage));
}

/************************************************************************************************************
 * @function    : tempDataGraph()
 * @description : Sensor's Temperature Data Graph
 **************************************************************************************************************/

function DataGraph(temp, hum, tare, Xaxis) {
    if (window.chart != undefined)
        window.chart.destroy();
    var ctx = document.getElementById('tempChart').getContext('2d');
    window.chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: Xaxis,
            datasets: [{
                label: "Net Weight",
                fill: false,
                pointRadius: 4,
                pointHoverRadius: 6,
                borderColor: '#0A467C',
                backgroundColor: '#0A467C',
                data: temp,
            },
            {
                label: "Gross Weight",
                fill: false,
                borderColor: "#22A7F0",
                pointRadius: 4,
                pointHoverRadius: 6,
                backgroundColor: '#22A7F0',
                data: hum
            },
            {
                label: "Tare Weight",
                fill: false,
                borderColor: "#FA3C25",
                pointRadius: 4,
                pointHoverRadius: 6,
                backgroundColor: '#FA3C25',
                data: tare
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Data Analysis'
            },
            tooltips: {
                mode: 'index',
                intersect: false,
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            scales: {
                xAxes: [{
                    display: true,

                    scaleLabel: {
                        display: true,
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        labelString: 'Temperature/Humidity'
                    },
                    ticks: {
                        max: 1300,
                        min: 0,
                        stepSize: 100
                    }
                }]
            }
        }
    });
}

/********************************************************************************************
 * @function    : oSendRequestToServer()
 * @description : Function called to send message to server
 *************************************************************************************************/
function oSendRequestToServer(inMessageToServer) {
    console.log("Sending: " + inMessageToServer);
    if (webSocketConnection.readyState != WebSocket.OPEN) {
        alert('ERROR : UNABLE TO CONNECT TO SERVER')
        return;
    }
    webSocketConnection.send(inMessageToServer);
}